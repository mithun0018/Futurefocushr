const { verifyAccessToken } = require('../utils/tokenUtils');
const AppError = require('../utils/AppError');
const catchAsync = require('../utils/catchAsync');
const Candidate = require('../models/Candidate');
const Admin = require('../models/Admin');

/**
 * Verifies the JWT access token from the Authorization header or cookie
 * and attaches the authenticated user + role to req.user
 */
const protect = catchAsync(async (req, res, next) => {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.accessToken) {
    token = req.cookies.accessToken;
  }

  if (!token) {
    return next(new AppError('You are not logged in. Please log in to access this resource.', 401));
  }

  let decoded;
  try {
    decoded = verifyAccessToken(token);
  } catch (err) {
    return next(new AppError('Invalid or expired token. Please log in again.', 401));
  }

  let currentUser;
  if (decoded.role === 'admin' || decoded.role === 'superadmin') {
    currentUser = await Admin.findById(decoded.id);
  } else {
    currentUser = await Candidate.findById(decoded.id);
  }

  if (!currentUser || !currentUser.isActive) {
    return next(new AppError('The user belonging to this token no longer exists or is inactive.', 401));
  }

  req.user = currentUser;
  req.userRole = decoded.role;
  next();
});

/**
 * Restricts access to specific roles.
 * Usage: restrictTo('admin', 'superadmin')
 */
const restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.userRole)) {
    return next(new AppError('You do not have permission to perform this action.', 403));
  }
  next();
};

module.exports = { protect, restrictTo };
