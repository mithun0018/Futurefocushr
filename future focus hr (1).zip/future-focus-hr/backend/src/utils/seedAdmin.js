/**
 * Run with: npm run seed:admin
 * Creates the first Admin account since there is no public admin-registration route.
 * Edit the values below (or pass as env vars) before running.
 */
const dotenv = require('dotenv');
dotenv.config();

const mongoose = require('mongoose');
const Admin = require('../models/Admin');
const logger = require('./logger');

const ADMIN_NAME = process.env.SEED_ADMIN_NAME || 'Super Admin';
const ADMIN_EMAIL = process.env.SEED_ADMIN_EMAIL || 'admin@futurefocushr.com';
const ADMIN_PASSWORD = process.env.SEED_ADMIN_PASSWORD || 'ChangeMe123!';

(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);

    const existing = await Admin.findOne({ email: ADMIN_EMAIL });
    if (existing) {
      logger.info(`Admin with email ${ADMIN_EMAIL} already exists. Skipping seed.`);
      process.exit(0);
    }

    const admin = await Admin.create({
      fullName: ADMIN_NAME,
      email: ADMIN_EMAIL,
      password: ADMIN_PASSWORD,
      role: 'superadmin',
    });

    logger.info(`Seeded admin account: ${admin.email} (change the password after first login!)`);
    process.exit(0);
  } catch (error) {
    logger.error(`Failed to seed admin: ${error.message}`);
    process.exit(1);
  }
})();
