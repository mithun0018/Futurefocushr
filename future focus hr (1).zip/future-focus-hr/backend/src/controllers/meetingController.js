const Meeting = require('../models/Meeting');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');
const { sendEmail } = require('../services/emailService');

// @desc Book a meeting/consultation
// @route POST /api/meetings
exports.createMeeting = catchAsync(async (req, res, next) => {
  const { name, email, phone, company, date, timeSlot, purpose } = req.body;

  const clash = await Meeting.findOne({ date, timeSlot, status: { $ne: 'Cancelled' } });
  if (clash) return next(new AppError('This time slot is already booked. Please choose another.', 409));

  const meeting = await Meeting.create({ name, email, phone, company, date, timeSlot, purpose });

  sendEmail({
    to: email,
    subject: 'Meeting Request Received - Future Focus HR Solutions',
    html: `<p>Hi ${name},</p><p>We've received your meeting request for <strong>${new Date(
      date
    ).toDateString()}</strong> at <strong>${timeSlot}</strong>. Our team will confirm shortly.</p>`,
  }).catch(() => {});

  return ApiResponse.success(res, 201, 'Meeting booked successfully', meeting);
});

// @desc Get all meetings (Admin)
// @route GET /api/meetings
exports.getMeetings = catchAsync(async (req, res) => {
  const { status, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);

  const [meetings, total] = await Promise.all([
    Meeting.find(filter).sort({ date: 1 }).skip(skip).limit(Number(limit)),
    Meeting.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Meetings fetched successfully', meetings, {
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// @desc Get single meeting
// @route GET /api/meetings/:id
exports.getMeetingById = catchAsync(async (req, res, next) => {
  const meeting = await Meeting.findById(req.params.id);
  if (!meeting) return next(new AppError('Meeting not found.', 404));
  return ApiResponse.success(res, 200, 'Meeting fetched successfully', meeting);
});

// @desc Update meeting (status, reschedule) - Admin
// @route PUT /api/meetings/:id
exports.updateMeeting = catchAsync(async (req, res, next) => {
  const meeting = await Meeting.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!meeting) return next(new AppError('Meeting not found.', 404));
  return ApiResponse.success(res, 200, 'Meeting updated successfully', meeting);
});

// @desc Delete/cancel a meeting
// @route DELETE /api/meetings/:id
exports.deleteMeeting = catchAsync(async (req, res, next) => {
  const meeting = await Meeting.findByIdAndDelete(req.params.id);
  if (!meeting) return next(new AppError('Meeting not found.', 404));
  return ApiResponse.success(res, 200, 'Meeting deleted successfully');
});
