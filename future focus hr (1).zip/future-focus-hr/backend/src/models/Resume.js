const mongoose = require('mongoose');

const resumeSchema = new mongoose.Schema(
  {
    candidate: { type: mongoose.Schema.Types.ObjectId, ref: 'Candidate', required: true },
    fileUrl: { type: String, required: true },
    fileName: { type: String, required: true },
    fileType: { type: String, enum: ['pdf', 'doc', 'docx'], required: true },
    extractedText: { type: String, default: '' },
    summary: { type: String, default: '' },
    extractedSkills: [{ type: String }],
    atsScore: { type: Number, default: 0, min: 0, max: 100 },
    missingKeywords: [{ type: String }],
    targetJob: { type: mongoose.Schema.Types.ObjectId, ref: 'Job' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Resume', resumeSchema);
