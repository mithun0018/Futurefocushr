import { Grid, Card, CardContent, Typography, Box, Avatar } from '@mui/material';
import WorkIcon from '@mui/icons-material/Work';
import PeopleIcon from '@mui/icons-material/People';
import EventAvailableIcon from '@mui/icons-material/EventAvailable';
import MailOutlineIcon from '@mui/icons-material/MailOutline';

// Placeholder stats — wire to GET /hr/dashboard/summary
const stats = [
  { label: 'Open Jobs', value: 8, icon: <WorkIcon /> },
  { label: 'Total Applicants', value: 142, icon: <PeopleIcon /> },
  { label: 'Interviews This Week', value: 5, icon: <EventAvailableIcon /> },
  { label: 'Offers Pending', value: 2, icon: <MailOutlineIcon /> },
];

export default function HRDashboard() {
  return (
    <Box>
      <Typography variant="h5" sx={{ fontWeight: 700, mb: 3 }}>HR Overview</Typography>
      <Grid container spacing={3}>
        {stats.map((s) => (
          <Grid item xs={12} sm={6} md={3} key={s.label}>
            <Card variant="outlined" sx={{ borderRadius: 3 }}>
              <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Avatar sx={{ bgcolor: 'primary.main' }}>{s.icon}</Avatar>
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 700 }}>{s.value}</Typography>
                  <Typography variant="body2" color="text.secondary">{s.label}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
