const express = require('express');
const applicationController = require('../controllers/applicationController');
const { protect, restrictTo } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const { createApplicationValidator, updateApplicationValidator } = require('../validators/applicationValidator');

const router = express.Router();

router.post('/', protect, createApplicationValidator, validate, applicationController.createApplication);
router.get('/', protect, applicationController.getApplications);
router.get('/:id', protect, applicationController.getApplicationById);
router.put(
  '/:id',
  protect,
  restrictTo('admin', 'superadmin'),
  updateApplicationValidator,
  validate,
  applicationController.updateApplication
);
router.delete('/:id', protect, applicationController.deleteApplication);

module.exports = router;
