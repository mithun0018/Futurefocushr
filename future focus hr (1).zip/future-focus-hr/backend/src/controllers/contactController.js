const Contact = require('../models/Contact');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');
const { sendEmail } = require('../services/emailService');

// @desc Submit a contact form
// @route POST /api/contact
exports.createContact = catchAsync(async (req, res) => {
  const { name, email, phone, subject, message } = req.body;
  const contact = await Contact.create({ name, email, phone, subject, message });

  sendEmail({
    to: email,
    subject: 'We received your message - Future Focus HR Solutions',
    html: `<p>Hi ${name},</p><p>Thank you for reaching out. Our team will get back to you shortly regarding: <strong>${subject}</strong>.</p>`,
  }).catch(() => {});

  return ApiResponse.success(res, 201, 'Your message has been submitted successfully', contact);
});

// @desc Get all contact requests (Admin)
// @route GET /api/contact
exports.getContacts = catchAsync(async (req, res) => {
  const { status, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (status) filter.status = status;

  const skip = (Number(page) - 1) * Number(limit);

  const [contacts, total] = await Promise.all([
    Contact.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Contact.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Contact requests fetched successfully', contacts, {
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// @desc Get single contact request (Admin)
// @route GET /api/contact/:id
exports.getContactById = catchAsync(async (req, res, next) => {
  const contact = await Contact.findById(req.params.id);
  if (!contact) return next(new AppError('Contact request not found.', 404));
  return ApiResponse.success(res, 200, 'Contact request fetched successfully', contact);
});

// @desc Update contact request status (Admin)
// @route PUT /api/contact/:id
exports.updateContact = catchAsync(async (req, res, next) => {
  const contact = await Contact.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!contact) return next(new AppError('Contact request not found.', 404));
  return ApiResponse.success(res, 200, 'Contact request updated successfully', contact);
});

// @desc Delete a contact request (Admin)
// @route DELETE /api/contact/:id
exports.deleteContact = catchAsync(async (req, res, next) => {
  const contact = await Contact.findByIdAndDelete(req.params.id);
  if (!contact) return next(new AppError('Contact request not found.', 404));
  return ApiResponse.success(res, 200, 'Contact request deleted successfully');
});
