const fs = require('fs');
const pdfParse = require('pdf-parse');
const mammoth = require('mammoth');

/**
 * Extracts raw text from an uploaded resume file (pdf, doc, docx)
 */
const extractText = async (filePath, fileType) => {
  if (fileType === 'pdf') {
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    return data.text;
  }

  if (fileType === 'docx' || fileType === 'doc') {
    const result = await mammoth.extractRawText({ path: filePath });
    return result.value;
  }

  throw new Error('Unsupported file type for text extraction');
};

// A curated list of common professional/technical skills to detect in resume text
const SKILL_KEYWORDS = [
  'javascript', 'typescript', 'node.js', 'nodejs', 'express', 'react', 'redux', 'vue', 'angular',
  'mongodb', 'mysql', 'postgresql', 'sql', 'nosql', 'firebase', 'aws', 'azure', 'gcp', 'docker',
  'kubernetes', 'git', 'github', 'ci/cd', 'html', 'css', 'sass', 'tailwind', 'bootstrap',
  'python', 'django', 'flask', 'java', 'spring', 'c++', 'c#', '.net', 'php', 'laravel',
  'communication', 'leadership', 'teamwork', 'problem solving', 'project management',
  'agile', 'scrum', 'recruitment', 'hr', 'payroll', 'onboarding', 'excel', 'powerpoint',
  'data analysis', 'machine learning', 'ai', 'rest api', 'graphql', 'microservices',
  'testing', 'jest', 'mocha', 'selenium', 'linux', 'devops', 'jenkins', 'terraform',
];

/**
 * Extracts skills mentioned in the resume by matching against a known keyword list
 */
const extractSkills = (text) => {
  const lowerText = text.toLowerCase();
  const found = SKILL_KEYWORDS.filter((skill) => lowerText.includes(skill));
  return [...new Set(found)];
};

/**
 * Generates a short auto-summary from the top of the resume text
 */
const generateSummary = (text) => {
  const cleaned = text.replace(/\s+/g, ' ').trim();
  return cleaned.length > 400 ? `${cleaned.slice(0, 400)}...` : cleaned;
};

/**
 * Very basic heuristic ATS score:
 * - Base score from number of recognized skills found
 * - Bonus for resume length/completeness
 * - Bonus for matching keywords against a target job description (if provided)
 */
const calculateATSScore = (resumeText, extractedSkills, jobDescription = '') => {
  let score = 0;

  // Skill coverage (up to 50 points)
  score += Math.min(extractedSkills.length * 5, 50);

  // Resume completeness / length (up to 20 points)
  const wordCount = resumeText.split(/\s+/).filter(Boolean).length;
  if (wordCount > 600) score += 20;
  else if (wordCount > 300) score += 12;
  else if (wordCount > 100) score += 6;

  // Contact/section presence (up to 10 points)
  const lowerText = resumeText.toLowerCase();
  if (lowerText.includes('experience')) score += 4;
  if (lowerText.includes('education')) score += 3;
  if (lowerText.includes('project')) score += 3;

  // Job description keyword match (up to 20 points)
  let missingKeywords = [];
  if (jobDescription) {
    const jdKeywords = extractSkills(jobDescription);
    const matched = jdKeywords.filter((kw) => lowerText.includes(kw));
    missingKeywords = jdKeywords.filter((kw) => !lowerText.includes(kw));
    if (jdKeywords.length > 0) {
      score += Math.round((matched.length / jdKeywords.length) * 20);
    }
  }

  return {
    score: Math.min(Math.round(score), 100),
    missingKeywords,
  };
};

module.exports = { extractText, extractSkills, generateSummary, calculateATSScore };
