const Application = require('../models/Application');
const Job = require('../models/Job');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');
const { sendApplicationStatusEmail } = require('../services/emailService');

// @desc Apply to a job (Candidate)
// @route POST /api/applications
exports.createApplication = catchAsync(async (req, res, next) => {
  const { job, resume, coverLetter } = req.body;

  const jobDoc = await Job.findById(job);
  if (!jobDoc) return next(new AppError('Job not found.', 404));
  if (jobDoc.status !== 'Open') return next(new AppError('This job is no longer accepting applications.', 400));

  const existing = await Application.findOne({ candidate: req.user._id, job });
  if (existing) return next(new AppError('You have already applied to this job.', 409));

  const application = await Application.create({
    candidate: req.user._id,
    job,
    resume,
    coverLetter,
  });

  return ApiResponse.success(res, 201, 'Application submitted successfully', application);
});

// @desc Get applications (Admin: all, filterable | Candidate: own applications)
// @route GET /api/applications
exports.getApplications = catchAsync(async (req, res) => {
  const { status, job, page = 1, limit = 10 } = req.query;
  const filter = {};

  const isAdmin = req.userRole === 'admin' || req.userRole === 'superadmin';
  if (!isAdmin) filter.candidate = req.user._id;

  if (status) filter.status = status;
  if (job) filter.job = job;

  const skip = (Number(page) - 1) * Number(limit);

  const [applications, total] = await Promise.all([
    Application.find(filter)
      .populate('candidate', 'fullName email phone resumeUrl')
      .populate('job', 'title department location employmentType')
      .populate('resume')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number(limit)),
    Application.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Applications fetched successfully', applications, {
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// @desc Get single application
// @route GET /api/applications/:id
exports.getApplicationById = catchAsync(async (req, res, next) => {
  const application = await Application.findById(req.params.id)
    .populate('candidate', 'fullName email phone resumeUrl skills')
    .populate('job')
    .populate('resume');

  if (!application) return next(new AppError('Application not found.', 404));

  const isAdmin = req.userRole === 'admin' || req.userRole === 'superadmin';
  if (!isAdmin && String(application.candidate._id) !== String(req.user._id)) {
    return next(new AppError('You are not authorized to view this application.', 403));
  }

  return ApiResponse.success(res, 200, 'Application fetched successfully', application);
});

// @desc Update application (status, interview date/feedback) - Admin
// @route PUT /api/applications/:id
exports.updateApplication = catchAsync(async (req, res, next) => {
  const application = await Application.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  })
    .populate('candidate', 'fullName email')
    .populate('job', 'title');

  if (!application) return next(new AppError('Application not found.', 404));

  if (req.body.status) {
    sendApplicationStatusEmail(
      application.candidate.email,
      application.candidate.fullName,
      application.job.title,
      req.body.status
    ).catch(() => {});
  }

  return ApiResponse.success(res, 200, 'Application updated successfully', application);
});

// @desc Delete/withdraw an application
// @route DELETE /api/applications/:id
exports.deleteApplication = catchAsync(async (req, res, next) => {
  const application = await Application.findById(req.params.id);
  if (!application) return next(new AppError('Application not found.', 404));

  const isAdmin = req.userRole === 'admin' || req.userRole === 'superadmin';
  if (!isAdmin && String(application.candidate) !== String(req.user._id)) {
    return next(new AppError('You are not authorized to delete this application.', 403));
  }

  await application.deleteOne();
  return ApiResponse.success(res, 200, 'Application deleted successfully');
});
