const path = require('path');
const fs = require('fs');
const Resume = require('../models/Resume');
const Candidate = require('../models/Candidate');
const Job = require('../models/Job');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');
const { allowedTypes } = require('../middleware/uploadMiddleware');
const { extractText, extractSkills, generateSummary, calculateATSScore } = require('../services/resumeParserService');
const { cloudinary, isConfigured } = require('../config/cloudinary');

// @desc Upload and parse a resume (PDF/DOC/DOCX)
// @route POST /api/resumes/upload
exports.uploadResume = catchAsync(async (req, res, next) => {
  if (!req.file) return next(new AppError('No resume file uploaded.', 400));

  const fileType = allowedTypes[req.file.mimetype];
  const localPath = req.file.path;

  const extractedText = await extractText(localPath, fileType);
  const extractedSkills = extractSkills(extractedText);
  const summary = generateSummary(extractedText);

  let targetJobDescription = '';
  if (req.body.jobId) {
    const job = await Job.findById(req.body.jobId);
    if (job) {
      targetJobDescription = [job.description, ...(job.requirements || [])].join(' ');
    }
  }

  const { score, missingKeywords } = calculateATSScore(extractedText, extractedSkills, targetJobDescription);

  let fileUrl = `/uploads/resumes/${req.file.filename}`;

  if (isConfigured) {
    const uploadResult = await cloudinary.uploader.upload(localPath, {
      folder: 'future-focus-hr/resumes',
      resource_type: 'raw',
    });
    fileUrl = uploadResult.secure_url;
    fs.unlink(localPath, () => {});
  }

  const resume = await Resume.create({
    candidate: req.user._id,
    fileUrl,
    fileName: req.file.originalname,
    fileType,
    extractedText,
    summary,
    extractedSkills,
    atsScore: score,
    missingKeywords,
    targetJob: req.body.jobId || undefined,
  });

  await Candidate.findByIdAndUpdate(req.user._id, {
    resumeUrl: fileUrl,
    resumeText: extractedText,
    atsScore: score,
    skills: extractedSkills,
  });

  return ApiResponse.success(res, 201, 'Resume uploaded and parsed successfully', resume);
});

// @desc Get all resumes for logged-in candidate
// @route GET /api/resumes
exports.getMyResumes = catchAsync(async (req, res) => {
  const resumes = await Resume.find({ candidate: req.user._id }).sort({ createdAt: -1 });
  return ApiResponse.success(res, 200, 'Resumes fetched successfully', resumes);
});

// @desc Get a single resume
// @route GET /api/resumes/:id
exports.getResumeById = catchAsync(async (req, res, next) => {
  const resume = await Resume.findById(req.params.id);
  if (!resume) return next(new AppError('Resume not found.', 404));

  const isAdmin = req.userRole === 'admin' || req.userRole === 'superadmin';
  if (!isAdmin && String(resume.candidate) !== String(req.user._id)) {
    return next(new AppError('You are not authorized to view this resume.', 403));
  }

  return ApiResponse.success(res, 200, 'Resume fetched successfully', resume);
});

// @desc Delete a resume
// @route DELETE /api/resumes/:id
exports.deleteResume = catchAsync(async (req, res, next) => {
  const resume = await Resume.findById(req.params.id);
  if (!resume) return next(new AppError('Resume not found.', 404));

  if (String(resume.candidate) !== String(req.user._id)) {
    return next(new AppError('You are not authorized to delete this resume.', 403));
  }

  if (!isConfigured && resume.fileUrl.startsWith('/uploads/')) {
    const filePath = path.join(__dirname, '../', resume.fileUrl);
    fs.unlink(filePath, () => {});
  }

  await resume.deleteOne();
  return ApiResponse.success(res, 200, 'Resume deleted successfully');
});
