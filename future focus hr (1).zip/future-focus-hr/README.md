# Future Focus HR Solutions — Full Project

This archive merges two parts of the project:

```
future-focus-hr/
  backend/     ← complete, runnable Node/Express/MongoDB API
  frontend/    ← ⚠️ CONFIG FILES ONLY — see warning below
```

## ⚠️ Important: frontend source code was not included

Only these frontend **config/scaffolding files** were uploaded and are present here:
`package.json`, `package-lock.json`, `vite.config.ts`, `index.html`, `postcss.config.js`,
`tailwind.config.js`, `tsconfig.json`, `tsconfig.node.json`, `.env.example`, `.gitignore`, `README.md`.

There is **no `src/` folder** — no `main.tsx`, `App.tsx`, components, pages, or routes. The
frontend's own `README.md` (included) describes a full structure (`components/auth`,
`components/careers`, `pages/`, `routes/AppRoutes.tsx`, etc.), but none of those files were
actually uploaded, so `npm run dev` in `frontend/` will not work as-is — Vite has nothing to
serve.

**To get a working frontend:** upload the actual `src/` folder (or the full project zip) from
wherever it currently lives, and I'll merge it in properly. If you don't have those files
anymore, let me know and I can scaffold a new React/TS/Tailwind frontend from scratch that
matches the page designs you shared earlier (hero.png, about.png, the full site mockup) and
wires it up to this backend's API.

## What's fully complete right now

- **`backend/`** — production-ready, all routes wired, tested for syntax errors, with its own
  `README.md` covering setup, environment variables, and the full API reference.
- **`frontend/`** — build tooling only, ready to receive real source files.

## Quick start (backend)
```bash
cd future-focus-hr/backend
npm install
cp .env.example .env
npm run seed:admin
npm run dev
```

## Quick start (frontend) — once real source files are added
```bash
cd future-focus-hr/frontend
npm install
npm run dev
```
