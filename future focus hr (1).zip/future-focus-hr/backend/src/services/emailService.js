const nodemailer = require('nodemailer');
const logger = require('../utils/logger');

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: Number(process.env.EMAIL_PORT) || 587,
  secure: Number(process.env.EMAIL_PORT) === 465,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

const sendEmail = async ({ to, subject, html, text }) => {
  try {
    const info = await transporter.sendMail({
      from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
      to,
      subject,
      html,
      text,
    });
    logger.info(`Email sent to ${to}: ${info.messageId}`);
    return info;
  } catch (error) {
    logger.error(`Failed to send email to ${to}: ${error.message}`);
    throw error;
  }
};

const sendOTPEmail = async (to, otp, purpose = 'reset-password') => {
  const subject =
    purpose === 'reset-password' ? 'Future Focus HR - Password Reset OTP' : 'Future Focus HR - Verify Your Email';

  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 500px; margin: auto;">
      <h2 style="color: #2f855a;">Future Focus HR Solutions</h2>
      <p>Your OTP code is:</p>
      <h1 style="letter-spacing: 4px; color: #1a365d;">${otp}</h1>
      <p>This code will expire in 10 minutes. If you did not request this, please ignore this email.</p>
    </div>
  `;

  return sendEmail({ to, subject, html, text: `Your OTP is ${otp}` });
};

const sendApplicationStatusEmail = async (to, candidateName, jobTitle, status) => {
  const subject = `Application Update: ${jobTitle}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 500px; margin: auto;">
      <h2 style="color: #2f855a;">Future Focus HR Solutions</h2>
      <p>Hi ${candidateName},</p>
      <p>Your application for <strong>${jobTitle}</strong> has been updated to: <strong>${status}</strong>.</p>
      <p>Log in to your candidate dashboard for more details.</p>
    </div>
  `;
  return sendEmail({ to, subject, html });
};

module.exports = { sendEmail, sendOTPEmail, sendApplicationStatusEmail };
