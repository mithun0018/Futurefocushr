const mongoose = require('mongoose');

const meetingSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, lowercase: true, trim: true },
    phone: { type: String, required: true, trim: true },
    company: { type: String, default: '' },
    date: { type: Date, required: true },
    timeSlot: { type: String, required: true },
    purpose: { type: String, default: '' },
    status: {
      type: String,
      enum: ['Pending', 'Confirmed', 'Completed', 'Cancelled'],
      default: 'Pending',
    },
  },
  { timestamps: true }
);

meetingSchema.index({ date: 1, timeSlot: 1 });

module.exports = mongoose.model('Meeting', meetingSchema);
