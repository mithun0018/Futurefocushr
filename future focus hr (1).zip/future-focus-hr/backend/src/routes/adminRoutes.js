const express = require('express');
const adminController = require('../controllers/adminController');
const { protect, restrictTo } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(protect, restrictTo('admin', 'superadmin'));

router.get('/dashboard/stats', adminController.getDashboardStats);
router.get('/dashboard/recent-applications', adminController.getRecentApplications);
router.get('/dashboard/recent-meetings', adminController.getRecentMeetings);
router.get('/dashboard/monthly-charts', adminController.getMonthlyCharts);
router.get('/candidates', adminController.getAllCandidates);

module.exports = router;
