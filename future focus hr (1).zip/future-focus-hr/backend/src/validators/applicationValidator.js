const { body } = require('express-validator');

exports.createApplicationValidator = [
  body('job').isMongoId().withMessage('A valid job ID is required'),
  body('resume').optional().isMongoId().withMessage('A valid resume ID is required'),
  body('coverLetter').optional().isString(),
];

exports.updateApplicationValidator = [
  body('status')
    .optional()
    .isIn([
      'Applied', 'Under Review', 'Shortlisted', 'Interview Scheduled',
      'Interviewed', 'Offered', 'Rejected', 'Hired',
    ]),
  body('interviewDate').optional().isISO8601().toDate(),
  body('interviewFeedback').optional().isString(),
];
