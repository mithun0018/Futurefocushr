const express = require('express');
const resumeController = require('../controllers/resumeController');
const { protect } = require('../middleware/authMiddleware');
const { uploadResume } = require('../middleware/uploadMiddleware');

const router = express.Router();

router.post('/upload', protect, uploadResume.single('resume'), resumeController.uploadResume);
router.get('/', protect, resumeController.getMyResumes);
router.get('/:id', protect, resumeController.getResumeById);
router.delete('/:id', protect, resumeController.deleteResume);

module.exports = router;
