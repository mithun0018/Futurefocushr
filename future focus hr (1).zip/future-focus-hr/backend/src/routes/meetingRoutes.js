const express = require('express');
const meetingController = require('../controllers/meetingController');
const { protect, restrictTo } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const { createMeetingValidator, updateMeetingValidator } = require('../validators/meetingValidator');

const router = express.Router();

router.post('/', createMeetingValidator, validate, meetingController.createMeeting);
router.get('/', protect, restrictTo('admin', 'superadmin'), meetingController.getMeetings);
router.get('/:id', protect, restrictTo('admin', 'superadmin'), meetingController.getMeetingById);
router.put(
  '/:id',
  protect,
  restrictTo('admin', 'superadmin'),
  updateMeetingValidator,
  validate,
  meetingController.updateMeeting
);
router.delete('/:id', protect, restrictTo('admin', 'superadmin'), meetingController.deleteMeeting);

module.exports = router;
