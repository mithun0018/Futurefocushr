const mongoose = require('mongoose');

const applicationSchema = new mongoose.Schema(
  {
    candidate: { type: mongoose.Schema.Types.ObjectId, ref: 'Candidate', required: true },
    job: { type: mongoose.Schema.Types.ObjectId, ref: 'Job', required: true },
    resume: { type: mongoose.Schema.Types.ObjectId, ref: 'Resume' },
    coverLetter: { type: String, default: '' },
    status: {
      type: String,
      enum: [
        'Applied',
        'Under Review',
        'Shortlisted',
        'Interview Scheduled',
        'Interviewed',
        'Offered',
        'Rejected',
        'Hired',
      ],
      default: 'Applied',
    },
    interviewDate: { type: Date },
    interviewFeedback: { type: String, default: '' },
    appliedDate: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

applicationSchema.index({ candidate: 1, job: 1 }, { unique: true });
applicationSchema.index({ status: 1 });

module.exports = mongoose.model('Application', applicationSchema);
