/**
 * Sends a consistent JSON response shape across the entire API.
 */
class ApiResponse {
  static success(res, statusCode = 200, message = 'Success', data = null, meta = null) {
    const body = { success: true, message };
    if (data !== null) body.data = data;
    if (meta !== null) body.meta = meta;
    return res.status(statusCode).json(body);
  }

  static error(res, statusCode = 500, message = 'Something went wrong', errors = null) {
    const body = { success: false, message };
    if (errors !== null) body.errors = errors;
    return res.status(statusCode).json(body);
  }
}

module.exports = ApiResponse;
