const { validationResult } = require('express-validator');
const ApiResponse = require('../utils/ApiResponse');

// Runs after express-validator check() chains; returns 422 with field errors if any failed
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) return next();

  const formatted = errors.array().map((e) => ({
    field: e.path,
    message: e.msg,
  }));

  return ApiResponse.error(res, 422, 'Validation failed', formatted);
};

module.exports = validate;
