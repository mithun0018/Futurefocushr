const express = require('express');
const contactController = require('../controllers/contactController');
const { protect, restrictTo } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const { createContactValidator, updateContactValidator } = require('../validators/contactValidator');

const router = express.Router();

router.post('/', createContactValidator, validate, contactController.createContact);
router.get('/', protect, restrictTo('admin', 'superadmin'), contactController.getContacts);
router.get('/:id', protect, restrictTo('admin', 'superadmin'), contactController.getContactById);
router.put(
  '/:id',
  protect,
  restrictTo('admin', 'superadmin'),
  updateContactValidator,
  validate,
  contactController.updateContact
);
router.delete('/:id', protect, restrictTo('admin', 'superadmin'), contactController.deleteContact);

module.exports = router;
