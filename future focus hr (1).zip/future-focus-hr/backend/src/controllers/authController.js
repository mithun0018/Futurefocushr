const crypto = require('crypto');
const Candidate = require('../models/Candidate');
const Admin = require('../models/Admin');
const OTP = require('../models/OTP');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');
const {
  generateAccessToken,
  generateRefreshToken,
  verifyRefreshToken,
  cookieOptions,
} = require('../utils/tokenUtils');
const { sendOTPEmail } = require('../services/emailService');

const getModelForRole = (role) => (role === 'admin' ? Admin : Candidate);

const issueTokens = async (res, user, role) => {
  const payload = { id: user._id, role: role === 'admin' ? user.role : 'candidate' };
  const accessToken = generateAccessToken(payload);
  const refreshToken = generateRefreshToken(payload);

  user.refreshToken = refreshToken;
  await user.save({ validateBeforeSave: false });

  res.cookie('accessToken', accessToken, {
    ...cookieOptions,
    maxAge: 15 * 60 * 1000,
  });
  res.cookie('refreshToken', refreshToken, cookieOptions);

  return { accessToken, refreshToken };
};

// @desc Register a new candidate
// @route POST /api/auth/register
exports.register = catchAsync(async (req, res, next) => {
  const { fullName, email, phone, password } = req.body;

  const existing = await Candidate.findOne({ email });
  if (existing) return next(new AppError('An account with this email already exists.', 409));

  const candidate = await Candidate.create({ fullName, email, phone, password });
  const tokens = await issueTokens(res, candidate, 'candidate');

  return ApiResponse.success(res, 201, 'Registration successful', {
    user: candidate.toSafeObject(),
    ...tokens,
  });
});

// @desc Login (candidate or admin)
// @route POST /api/auth/login
exports.login = catchAsync(async (req, res, next) => {
  const { email, password, role } = req.body;
  const Model = getModelForRole(role);

  const user = await Model.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    return next(new AppError('Incorrect email or password.', 401));
  }

  if (!user.isActive) {
    return next(new AppError('This account has been deactivated. Contact support.', 403));
  }

  const tokens = await issueTokens(res, user, role);

  return ApiResponse.success(res, 200, 'Login successful', {
    user: user.toSafeObject(),
    ...tokens,
  });
});

// @desc Logout
// @route POST /api/auth/logout
exports.logout = catchAsync(async (req, res) => {
  const Model = getModelForRole(req.userRole === 'admin' || req.userRole === 'superadmin' ? 'admin' : 'candidate');
  await Model.findByIdAndUpdate(req.user._id, { refreshToken: '' });

  res.clearCookie('accessToken');
  res.clearCookie('refreshToken');

  return ApiResponse.success(res, 200, 'Logged out successfully');
});

// @desc Refresh access token using refresh token
// @route POST /api/auth/refresh-token
exports.refreshToken = catchAsync(async (req, res, next) => {
  const token = req.cookies?.refreshToken || req.body.refreshToken;
  if (!token) return next(new AppError('Refresh token missing.', 401));

  let decoded;
  try {
    decoded = verifyRefreshToken(token);
  } catch (err) {
    return next(new AppError('Invalid or expired refresh token.', 401));
  }

  const Model = getModelForRole(decoded.role === 'admin' || decoded.role === 'superadmin' ? 'admin' : 'candidate');
  const user = await Model.findById(decoded.id).select('+refreshToken');

  if (!user || user.refreshToken !== token) {
    return next(new AppError('Refresh token is invalid or has been revoked.', 401));
  }

  const accessToken = generateAccessToken({ id: user._id, role: decoded.role });
  res.cookie('accessToken', accessToken, { ...cookieOptions, maxAge: 15 * 60 * 1000 });

  return ApiResponse.success(res, 200, 'Token refreshed', { accessToken });
});

// @desc Request a password reset OTP
// @route POST /api/auth/forgot-password
exports.forgotPassword = catchAsync(async (req, res, next) => {
  const { email, role } = req.body;
  const Model = getModelForRole(role);

  const user = await Model.findOne({ email });
  if (!user) return next(new AppError('No account found with this email.', 404));

  const otp = crypto.randomInt(100000, 999999).toString();
  const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

  await OTP.create({ email, otp, purpose: 'reset-password', expiresAt });
  await sendOTPEmail(email, otp, 'reset-password');

  return ApiResponse.success(res, 200, 'OTP sent to your email for password reset.');
});

// @desc Reset password using OTP
// @route POST /api/auth/reset-password
exports.resetPassword = catchAsync(async (req, res, next) => {
  const { email, otp, newPassword, role } = req.body;

  const otpRecord = await OTP.findOne({ email, otp, purpose: 'reset-password', consumed: false }).sort({
    createdAt: -1,
  });

  if (!otpRecord || otpRecord.expiresAt < new Date()) {
    return next(new AppError('Invalid or expired OTP.', 400));
  }

  const Model = getModelForRole(role);
  const user = await Model.findOne({ email });
  if (!user) return next(new AppError('No account found with this email.', 404));

  user.password = newPassword;
  user.refreshToken = '';
  await user.save();

  otpRecord.consumed = true;
  await otpRecord.save();

  return ApiResponse.success(res, 200, 'Password reset successful. Please log in with your new password.');
});

// @desc Change password (authenticated user)
// @route POST /api/auth/change-password
exports.changePassword = catchAsync(async (req, res, next) => {
  const { currentPassword, newPassword } = req.body;
  const Model = getModelForRole(req.userRole === 'admin' || req.userRole === 'superadmin' ? 'admin' : 'candidate');

  const user = await Model.findById(req.user._id).select('+password');
  if (!(await user.comparePassword(currentPassword))) {
    return next(new AppError('Current password is incorrect.', 401));
  }

  user.password = newPassword;
  await user.save();

  return ApiResponse.success(res, 200, 'Password changed successfully.');
});

// @desc Get currently logged in user profile
// @route GET /api/auth/me
exports.getMe = catchAsync(async (req, res) => {
  return ApiResponse.success(res, 200, 'Current user fetched', { user: req.user.toSafeObject() });
});
