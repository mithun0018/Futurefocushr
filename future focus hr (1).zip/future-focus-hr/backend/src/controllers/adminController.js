const Job = require('../models/Job');
const Candidate = require('../models/Candidate');
const Application = require('../models/Application');
const Meeting = require('../models/Meeting');
const Contact = require('../models/Contact');
const catchAsync = require('../utils/catchAsync');
const ApiResponse = require('../utils/ApiResponse');

// @desc Get admin dashboard statistics
// @route GET /api/admin/dashboard/stats
exports.getDashboardStats = catchAsync(async (req, res) => {
  const [totalJobs, openJobs, totalCandidates, totalApplications, totalMeetings, totalContacts] = await Promise.all([
    Job.countDocuments(),
    Job.countDocuments({ status: 'Open' }),
    Candidate.countDocuments(),
    Application.countDocuments(),
    Meeting.countDocuments(),
    Contact.countDocuments(),
  ]);

  return ApiResponse.success(res, 200, 'Dashboard statistics fetched successfully', {
    totalJobs,
    openJobs,
    totalCandidates,
    totalApplications,
    totalMeetings,
    totalContacts,
  });
});

// @desc Get recent applications (Admin dashboard widget)
// @route GET /api/admin/dashboard/recent-applications
exports.getRecentApplications = catchAsync(async (req, res) => {
  const applications = await Application.find()
    .populate('candidate', 'fullName email')
    .populate('job', 'title department')
    .sort({ createdAt: -1 })
    .limit(10);

  return ApiResponse.success(res, 200, 'Recent applications fetched successfully', applications);
});

// @desc Get recent meetings (Admin dashboard widget)
// @route GET /api/admin/dashboard/recent-meetings
exports.getRecentMeetings = catchAsync(async (req, res) => {
  const meetings = await Meeting.find().sort({ createdAt: -1 }).limit(10);
  return ApiResponse.success(res, 200, 'Recent meetings fetched successfully', meetings);
});

// @desc Get monthly chart data (applications & meetings per month, current year)
// @route GET /api/admin/dashboard/monthly-charts
exports.getMonthlyCharts = catchAsync(async (req, res) => {
  const year = Number(req.query.year) || new Date().getFullYear();
  const startOfYear = new Date(`${year}-01-01T00:00:00.000Z`);
  const endOfYear = new Date(`${year}-12-31T23:59:59.999Z`);

  const buildMonthlySeries = async (Model, dateField = 'createdAt') => {
    const results = await Model.aggregate([
      { $match: { [dateField]: { $gte: startOfYear, $lte: endOfYear } } },
      {
        $group: {
          _id: { $month: `$${dateField}` },
          count: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    const months = Array.from({ length: 12 }, (_, i) => ({ month: i + 1, count: 0 }));
    results.forEach((r) => {
      months[r._id - 1].count = r.count;
    });
    return months;
  };

  const [applicationsPerMonth, candidatesPerMonth, meetingsPerMonth] = await Promise.all([
    buildMonthlySeries(Application, 'appliedDate'),
    buildMonthlySeries(Candidate, 'createdAt'),
    buildMonthlySeries(Meeting, 'createdAt'),
  ]);

  return ApiResponse.success(res, 200, 'Monthly chart data fetched successfully', {
    year,
    applicationsPerMonth,
    candidatesPerMonth,
    meetingsPerMonth,
  });
});

// @desc Get all candidates (Admin)
// @route GET /api/admin/candidates
exports.getAllCandidates = catchAsync(async (req, res) => {
  const { search, page = 1, limit = 10 } = req.query;
  const filter = {};
  if (search) {
    filter.$or = [
      { fullName: new RegExp(search, 'i') },
      { email: new RegExp(search, 'i') },
      { skills: new RegExp(search, 'i') },
    ];
  }

  const skip = (Number(page) - 1) * Number(limit);
  const [candidates, total] = await Promise.all([
    Candidate.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Candidate.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Candidates fetched successfully', candidates, {
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});
