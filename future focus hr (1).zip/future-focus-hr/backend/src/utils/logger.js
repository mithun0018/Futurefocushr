const morgan = require('morgan');
const fs = require('fs');
const path = require('path');

const logDir = path.join(__dirname, '../../logs');
if (!fs.existsSync(logDir)) {
  fs.mkdirSync(logDir, { recursive: true });
}

const logFilePath = path.join(logDir, 'app.log');

const writeToFile = (level, message) => {
  const line = `[${new Date().toISOString()}] [${level}] ${message}\n`;
  fs.appendFile(logFilePath, line, () => {});
};

const logger = {
  info: (message) => {
    console.log(`\x1b[36m[INFO]\x1b[0m ${message}`);
    writeToFile('INFO', message);
  },
  warn: (message) => {
    console.warn(`\x1b[33m[WARN]\x1b[0m ${message}`);
    writeToFile('WARN', message);
  },
  error: (message) => {
    console.error(`\x1b[31m[ERROR]\x1b[0m ${message}`);
    writeToFile('ERROR', message);
  },
};

const morganStream = {
  write: (message) => writeToFile('HTTP', message.trim()),
};

const httpLogger = morgan(
  process.env.NODE_ENV === 'production' ? 'combined' : 'dev',
  { stream: morganStream }
);

module.exports = logger;
module.exports.httpLogger = httpLogger;
