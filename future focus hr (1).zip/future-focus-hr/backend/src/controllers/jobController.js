const Job = require('../models/Job');
const catchAsync = require('../utils/catchAsync');
const AppError = require('../utils/AppError');
const ApiResponse = require('../utils/ApiResponse');

// @desc Get all jobs (with filters, search, pagination)
// @route GET /api/jobs
exports.getJobs = catchAsync(async (req, res) => {
  const {
    search, location, department, employmentType, experience,
    status = 'Open', page = 1, limit = 10,
  } = req.query;

  const filter = {};
  if (status) filter.status = status;
  if (location) filter.location = new RegExp(location, 'i');
  if (department) filter.department = new RegExp(department, 'i');
  if (employmentType) filter.employmentType = employmentType;
  if (experience) filter.experience = new RegExp(experience, 'i');
  if (search) filter.$text = { $search: search };

  const skip = (Number(page) - 1) * Number(limit);

  const [jobs, total] = await Promise.all([
    Job.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)),
    Job.countDocuments(filter),
  ]);

  return ApiResponse.success(res, 200, 'Jobs fetched successfully', jobs, {
    total,
    page: Number(page),
    pages: Math.ceil(total / Number(limit)),
  });
});

// @desc Get a single job by ID
// @route GET /api/jobs/:id
exports.getJobById = catchAsync(async (req, res, next) => {
  const job = await Job.findById(req.params.id);
  if (!job) return next(new AppError('Job not found.', 404));
  return ApiResponse.success(res, 200, 'Job fetched successfully', job);
});

// @desc Create a new job posting (Admin)
// @route POST /api/jobs
exports.createJob = catchAsync(async (req, res) => {
  const job = await Job.create({ ...req.body, createdBy: req.user._id });
  return ApiResponse.success(res, 201, 'Job created successfully', job);
});

// @desc Update a job posting (Admin)
// @route PUT /api/jobs/:id
exports.updateJob = catchAsync(async (req, res, next) => {
  const job = await Job.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });
  if (!job) return next(new AppError('Job not found.', 404));
  return ApiResponse.success(res, 200, 'Job updated successfully', job);
});

// @desc Delete a job posting (Admin)
// @route DELETE /api/jobs/:id
exports.deleteJob = catchAsync(async (req, res, next) => {
  const job = await Job.findByIdAndDelete(req.params.id);
  if (!job) return next(new AppError('Job not found.', 404));
  return ApiResponse.success(res, 200, 'Job deleted successfully');
});
