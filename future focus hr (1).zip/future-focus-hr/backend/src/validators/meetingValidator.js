const { body } = require('express-validator');

exports.createMeetingValidator = [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('A valid email is required').normalizeEmail(),
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('date').isISO8601().withMessage('A valid date is required').toDate(),
  body('timeSlot').notEmpty().withMessage('Time slot is required'),
  body('company').optional().isString(),
  body('purpose').optional().isString(),
];

exports.updateMeetingValidator = [
  body('status').optional().isIn(['Pending', 'Confirmed', 'Completed', 'Cancelled']),
  body('date').optional().isISO8601().toDate(),
  body('timeSlot').optional().isString(),
];
