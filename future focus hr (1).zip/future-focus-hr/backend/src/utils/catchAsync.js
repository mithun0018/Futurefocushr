// Wraps async controller functions so errors are forwarded to the
// centralized error handler instead of requiring try/catch everywhere.
const catchAsync = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = catchAsync;
