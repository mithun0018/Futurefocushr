const { body } = require('express-validator');

exports.createJobValidator = [
  body('title').trim().notEmpty().withMessage('Job title is required'),
  body('department').trim().notEmpty().withMessage('Department is required'),
  body('location').trim().notEmpty().withMessage('Location is required'),
  body('description').trim().notEmpty().withMessage('Job description is required'),
  body('employmentType')
    .optional()
    .isIn(['Full Time', 'Part Time', 'Contract', 'Internship', 'Remote']),
  body('responsibilities').optional().isArray(),
  body('requirements').optional().isArray(),
  body('benefits').optional().isArray(),
];

exports.updateJobValidator = [
  body('title').optional().trim().notEmpty(),
  body('department').optional().trim().notEmpty(),
  body('location').optional().trim().notEmpty(),
  body('status').optional().isIn(['Open', 'Closed', 'Draft']),
];
