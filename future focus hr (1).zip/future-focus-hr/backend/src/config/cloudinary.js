const cloudinary = require('cloudinary').v2;

const isConfigured =
  process.env.USE_CLOUDINARY === 'true' &&
  process.env.CLOUDINARY_NAME &&
  process.env.CLOUDINARY_KEY &&
  process.env.CLOUDINARY_SECRET;

if (isConfigured) {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_NAME,
    api_key: process.env.CLOUDINARY_KEY,
    api_secret: process.env.CLOUDINARY_SECRET,
  });
}

module.exports = { cloudinary, isConfigured };
