const express = require('express');
const jobController = require('../controllers/jobController');
const { protect, restrictTo } = require('../middleware/authMiddleware');
const validate = require('../middleware/validate');
const { createJobValidator, updateJobValidator } = require('../validators/jobValidator');

const router = express.Router();

router.get('/', jobController.getJobs);
router.get('/:id', jobController.getJobById);

router.post('/', protect, restrictTo('admin', 'superadmin'), createJobValidator, validate, jobController.createJob);
router.put('/:id', protect, restrictTo('admin', 'superadmin'), updateJobValidator, validate, jobController.updateJob);
router.delete('/:id', protect, restrictTo('admin', 'superadmin'), jobController.deleteJob);

module.exports = router;
