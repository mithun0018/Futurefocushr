# Future Focus HR Solutions — Frontend

React + TypeScript + Vite + Tailwind CSS frontend for Future Focus HR Solutions.

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Run the dev server
npm run dev
# App runs at http://localhost:5173

# 3. Build for production
npm run build

# 4. Preview the production build
npm run preview
```

## Project Structure

```
src/
  components/
    auth/         → LoginForm, RegisterForm
    careers/       → JobCard, JobFilters, ApplicationForm
    common/        → shared UI primitives (Button, Input, Card, Modal, etc.)
    dashboard/     → Sidebar, TopNav, ApplicantTable, JobTable, RecentActivity
    home/          → homepage sections
    layout/        → Navbar, Footer, MainLayout
  context/         → AuthContext (in-memory auth state; no backend wired up yet)
  pages/           → route-level pages
  routes/          → AppRoutes.tsx (React Router route table)
  services/        → static data (jobs, services, testimonials)
  types/           → shared TypeScript interfaces
```

## Routes

| Path              | Page          |
|-------------------|---------------|
| `/`               | Home          |
| `/about`          | About         |
| `/services`       | Services      |
| `/services/:slug` | ServiceDetail |
| `/careers`        | Careers       |
| `/careers/:id`    | JobDetails    |
| `/contact`        | Contact       |
| `/login`          | Login         |
| `/register`       | Register      |
| `/dashboard`      | Dashboard     |
| `*`               | NotFound      |

## Notes

- Authentication is currently mocked via `AuthContext` (in-memory only, resets on refresh). Wire up a real API before shipping to production.
- The Google login button on the Login page is a placeholder — it shows a toast and does not perform real OAuth.
- The Contact form and Application form simulate a network request (`setTimeout`) and show a success toast; wire up a real endpoint to actually send data anywhere.
- The map on the Contact page is a placeholder block — swap in Google Maps / Mapbox embed when ready.
- No `.env` variables are required yet since there's no backend integration. When you add one (e.g. an API base URL), create a `.env` file based on `.env.example` and read it via `import.meta.env.VITE_*`.

## Verifying the Build

This environment could not run `npm install` (no network access), so the build has **not** been executed here. After unzipping locally, run:

```bash
npm install
npm run build
```

and fix any TypeScript errors that surface, if any.
