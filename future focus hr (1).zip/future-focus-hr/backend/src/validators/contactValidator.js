const { body } = require('express-validator');

exports.createContactValidator = [
  body('name').trim().notEmpty().withMessage('Name is required'),
  body('email').isEmail().withMessage('A valid email is required').normalizeEmail(),
  body('phone').optional().isString(),
  body('subject').trim().notEmpty().withMessage('Subject is required'),
  body('message').trim().notEmpty().withMessage('Message is required'),
];

exports.updateContactValidator = [
  body('status').optional().isIn(['New', 'In Progress', 'Resolved']),
];
