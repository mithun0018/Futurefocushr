# Future Focus HR Solutions — Backend API

Production-ready Node.js/Express/MongoDB backend for the Future Focus HR Solutions website (Home, About, Services, Careers, Contact, Login/Register, Candidate Dashboard, Admin Dashboard, Meeting Scheduler).

## Tech Stack
Node.js · Express.js · MongoDB · Mongoose · JWT · bcrypt · Multer · Cloudinary (optional) · Nodemailer · pdf-parse · mammoth (docx parsing)

## 1. Setup

```bash
cd backend
npm install
cp .env.example .env
# edit .env with your real values
npm run dev        # starts with nodemon on PORT (default 5000)
```

Create the first admin account (no public admin-signup route by design):

```bash
# optionally set SEED_ADMIN_NAME / SEED_ADMIN_EMAIL / SEED_ADMIN_PASSWORD env vars first
npm run seed:admin
```

## 2. Environment Variables
See `.env.example`. Key ones:
- `MONGODB_URI` — MongoDB connection string
- `JWT_SECRET` / `REFRESH_SECRET` — long random strings
- `EMAIL_*` — SMTP credentials for OTP + notification emails
- `CLIENT_URL` — your frontend origin(s), comma-separated, used for CORS
- `USE_CLOUDINARY` — set `true` + Cloudinary creds to store resumes in the cloud instead of local disk

## 3. Folder Structure
```
backend/
  src/
    config/        # db.js, cloudinary.js
    controllers/    # business logic per resource
    middleware/     # auth, error handling, upload, rate limiting, validation
    models/         # Mongoose schemas
    routes/         # Express routers, mounted under /api
    services/       # email, resume parsing/ATS scoring
    utils/          # logger, AppError, ApiResponse, tokenUtils, seedAdmin
    validators/      # express-validator rule sets
    uploads/        # local resume storage (if not using Cloudinary)
    logs/           # app.log (morgan + app logger)
    app.js          # Express app (middleware + routes)
    server.js       # entry point
  package.json
  .env.example
```

## 4. API Reference (base path `/api`)

### Auth — `/auth`
| Method | Route | Auth | Description |
|---|---|---|---|
| POST | `/auth/register` | Public | Register a candidate |
| POST | `/auth/login` | Public | Login (body: `{ email, password, role }`, role = `candidate`\|`admin`) |
| POST | `/auth/logout` | Bearer | Logout, clears refresh token |
| POST | `/auth/refresh-token` | Cookie/body | Get a new access token |
| POST | `/auth/forgot-password` | Public | Sends OTP email |
| POST | `/auth/reset-password` | Public | Reset password using OTP |
| POST | `/auth/change-password` | Bearer | Change password while logged in |
| GET  | `/auth/me` | Bearer | Get current user profile |

### Jobs — `/jobs`
| Method | Route | Auth |
|---|---|---|
| GET | `/jobs` | Public (query: search, location, department, employmentType, experience, status, page, limit) |
| GET | `/jobs/:id` | Public |
| POST | `/jobs` | Admin |
| PUT | `/jobs/:id` | Admin |
| DELETE | `/jobs/:id` | Admin |

### Applications — `/applications`
| Method | Route | Auth |
|---|---|---|
| POST | `/applications` | Candidate |
| GET | `/applications` | Candidate (own) / Admin (all, filterable) |
| GET | `/applications/:id` | Owner or Admin |
| PUT | `/applications/:id` | Admin |
| DELETE | `/applications/:id` | Owner or Admin |

### Resumes — `/resumes`
| Method | Route | Auth |
|---|---|---|
| POST | `/resumes/upload` | Candidate (multipart field `resume`, optional `jobId` to score against a job) |
| GET | `/resumes` | Candidate (own) |
| GET | `/resumes/:id` | Owner or Admin |
| DELETE | `/resumes/:id` | Owner |

### Meetings — `/meetings`
| Method | Route | Auth |
|---|---|---|
| POST | `/meetings` | Public (book a consultation) |
| GET | `/meetings` | Admin |
| GET | `/meetings/:id` | Admin |
| PUT | `/meetings/:id` | Admin |
| DELETE | `/meetings/:id` | Admin |

### Contact — `/contact`
| Method | Route | Auth |
|---|---|---|
| POST | `/contact` | Public |
| GET | `/contact` | Admin |
| GET | `/contact/:id` | Admin |
| PUT | `/contact/:id` | Admin |
| DELETE | `/contact/:id` | Admin |

### Admin Dashboard — `/admin`
| Method | Route | Auth |
|---|---|---|
| GET | `/admin/dashboard/stats` | Admin |
| GET | `/admin/dashboard/recent-applications` | Admin |
| GET | `/admin/dashboard/recent-meetings` | Admin |
| GET | `/admin/dashboard/monthly-charts` | Admin (query: `year`) |
| GET | `/admin/candidates` | Admin (query: search, page, limit) |

### Misc
- `GET /api/health` — health check
- `GET /` — root status check

## 5. Auth Model
- Access token (short-lived, 15m) + refresh token (7d), both delivered as httpOnly cookies and in the JSON response body.
- Send `Authorization: Bearer <accessToken>` **or** rely on the `accessToken` cookie.
- Roles: `candidate`, `admin`, `superadmin`.

## 6. Response Shape
```json
{ "success": true, "message": "...", "data": { }, "meta": { "total": 0, "page": 1, "pages": 1 } }
```
Errors:
```json
{ "success": false, "message": "...", "errors": [ { "field": "email", "message": "..." } ] }
```

## 7. Security
Helmet, CORS (origin-restricted via `CLIENT_URL`), rate limiting (global + stricter on auth routes), `express-mongo-sanitize`, `xss-clean`, bcrypt password hashing, JWT auth, centralized error handler that hides stack traces in production.

## 8. Deployment Notes
- Use a process manager (PM2) or your platform's Node runtime; start command: `npm start`.
- Set `NODE_ENV=production` and rotate `JWT_SECRET`/`REFRESH_SECRET` to strong random values.
- Point `MONGODB_URI` at Atlas or your managed Mongo instance.
- Set `USE_CLOUDINARY=true` in any stateless/containerized deployment (e.g. Render, Railway, Heroku) since local disk storage won't persist across deploys/restarts.
- Put the API behind HTTPS (e.g. via the platform's TLS termination or a reverse proxy like Nginx) — cookies are marked `secure` in production.
- Update `CLIENT_URL` to your deployed frontend origin(s), comma-separated if more than one.

## 9. Connecting Your Frontend
Match these base routes to your existing pages:
- Login/Register pages → `/api/auth/login`, `/api/auth/register`
- Careers/job listing + detail pages → `/api/jobs`, `/api/jobs/:id`
- Job apply flow → upload resume via `/api/resumes/upload`, then `POST /api/applications`
- Candidate Dashboard → `/api/auth/me`, `/api/applications`, `/api/resumes`
- Meeting Scheduler UI → `/api/meetings`
- Contact page → `/api/contact`
- Admin Dashboard UI → `/api/admin/dashboard/*`, `/api/jobs`, `/api/applications`, `/api/meetings`, `/api/contact`, `/api/admin/candidates`
