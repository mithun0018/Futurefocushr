import { Routes, Route } from 'react-router-dom';

import PublicLayout from './components/layout/PublicLayout';
import ProtectedRoute from './routes/ProtectedRoute';

import HomePage from './pages/public/HomePage';
import AboutPage from './pages/public/AboutPage';
import ServicesPage from './pages/public/ServicesPage';
import IndustriesPage from './pages/public/IndustriesPage';
import TestimonialsPage from './pages/public/TestimonialsPage';
import ContactPage from './pages/public/ContactPage';
import FAQPage from './pages/public/FAQPage';
import PrivacyPage from './pages/public/PrivacyPage';
import TermsPage from './pages/public/TermsPage';
import NotFoundPage from './pages/public/NotFoundPage';

import JobListingPage from './pages/careers/JobListingPage';
import JobDetailPage from './pages/careers/JobDetailPage';

import BlogListPage from './pages/blog/BlogListPage';
import BlogDetailPage from './pages/blog/BlogDetailPage';

import LoginPage from './features/auth/LoginPage';
import RegisterPage from './features/auth/RegisterPage';
import ForgotPasswordPage from './features/auth/ForgotPasswordPage';

import CandidateLayout from './pages/dashboard/candidate/CandidateLayout';
import CandidateDashboard from './pages/dashboard/candidate/CandidateDashboard';

import HRLayout from './pages/dashboard/hr/HRLayout';
import HRDashboard from './pages/dashboard/hr/HRDashboard';

import AdminLayout from './pages/dashboard/admin/AdminLayout';
import AdminDashboard from './pages/dashboard/admin/AdminDashboard';

import PlaceholderPage from './components/common/PlaceholderPage';

export default function App() {
  return (
    <Routes>
      {/* Public site */}
      <Route element={<PublicLayout />}>
        <Route path="/" element={<HomePage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/services" element={<ServicesPage />} />
        <Route path="/industries" element={<IndustriesPage />} />
        <Route path="/testimonials" element={<TestimonialsPage />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/faqs" element={<FAQPage />} />
        <Route path="/privacy" element={<PrivacyPage />} />
        <Route path="/terms" element={<TermsPage />} />

        <Route path="/careers" element={<JobListingPage />} />
        <Route path="/careers/:jobId" element={<JobDetailPage />} />

        <Route path="/blog" element={<BlogListPage />} />
        <Route path="/blog/:postId" element={<BlogDetailPage />} />

        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
      </Route>

      {/* Candidate portal */}
      <Route element={<ProtectedRoute allowedRoles={['candidate']} />}>
        <Route element={<CandidateLayout />}>
          <Route path="/candidate/dashboard" element={<CandidateDashboard />} />
          <Route
            path="/candidate/profile"
            element={<PlaceholderPage title="My Profile" description="Education, experience, skills, resume, and certificates — connect to GET/PUT /candidates/me." />}
          />
          <Route
            path="/candidate/applications"
            element={<PlaceholderPage title="Applied Jobs" description="Track application status here — connect to GET /candidates/me/applications." />}
          />
          <Route
            path="/candidate/saved"
            element={<PlaceholderPage title="Saved Jobs" description="Your bookmarked roles — connect to GET /candidates/me/saved-jobs." />}
          />
          <Route
            path="/candidate/interviews"
            element={<PlaceholderPage title="Interview Schedule" description="Upcoming interviews — connect to GET /candidates/me/interviews." />}
          />
          <Route
            path="/candidate/settings"
            element={<PlaceholderPage title="Settings" description="Account and notification preferences — connect to PUT /candidates/me/settings." />}
          />
        </Route>
      </Route>

      {/* HR / Recruiter panel */}
      <Route element={<ProtectedRoute allowedRoles={['hr', 'recruiter']} />}>
        <Route element={<HRLayout />}>
          <Route path="/hr/dashboard" element={<HRDashboard />} />
          <Route
            path="/hr/jobs"
            element={<PlaceholderPage title="Manage Jobs" description="Create, update, and close job postings — connect to /hr/jobs CRUD API." />}
          />
          <Route
            path="/hr/applicants"
            element={<PlaceholderPage title="Applicants" description="Shortlist, reject, and track candidates — connect to GET /hr/applications." />}
          />
          <Route
            path="/hr/interviews"
            element={<PlaceholderPage title="Interviews" description="Schedule interviews and upload feedback — connect to /hr/interviews API." />}
          />
          <Route
            path="/hr/offers"
            element={<PlaceholderPage title="Offer Letters" description="Send and track offer letters — connect to /hr/offers API." />}
          />
        </Route>
      </Route>

      {/* Admin panel */}
      <Route element={<ProtectedRoute allowedRoles={['admin']} />}>
        <Route element={<AdminLayout />}>
          <Route path="/admin/dashboard" element={<AdminDashboard />} />
          <Route
            path="/admin/users"
            element={<PlaceholderPage title="Manage Users" description="View and manage all platform users — connect to GET /admin/users." />}
          />
          <Route
            path="/admin/jobs"
            element={<PlaceholderPage title="Manage Jobs" description="Oversee all job postings across HR accounts — connect to GET /admin/jobs." />}
          />
          <Route
            path="/admin/blogs"
            element={<PlaceholderPage title="Manage Blogs" description="Create and edit blog content — connect to /admin/blogs CRUD API." />}
          />
          <Route
            path="/admin/testimonials"
            element={<PlaceholderPage title="Manage Testimonials" description="Approve and curate client testimonials — connect to /admin/testimonials API." />}
          />
          <Route
            path="/admin/messages"
            element={<PlaceholderPage title="Contact Messages" description="Review inbound contact form submissions — connect to GET /admin/contact-messages." />}
          />
          <Route
            path="/admin/roles"
            element={<PlaceholderPage title="Roles & Permissions" description="Configure role-based access control — connect to /admin/roles API." />}
          />
        </Route>
      </Route>

      <Route path="*" element={<NotFoundPage />} />
    </Routes>
  );
}
