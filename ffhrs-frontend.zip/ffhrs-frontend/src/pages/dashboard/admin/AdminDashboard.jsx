import { Grid, Card, CardContent, Typography, Box, Avatar } from '@mui/material';
import PeopleIcon from '@mui/icons-material/People';
import WorkIcon from '@mui/icons-material/Work';
import ArticleIcon from '@mui/icons-material/Article';
import MailOutlineIcon from '@mui/icons-material/MailOutline';

// Placeholder stats — wire to GET /admin/dashboard/analytics
const stats = [
  { label: 'Total Users', value: '1,248', icon: <PeopleIcon /> },
  { label: 'Active Jobs', value: 34, icon: <WorkIcon /> },
  { label: 'Blog Posts', value: 27, icon: <ArticleIcon /> },
  { label: 'Contact Messages', value: 19, icon: <MailOutlineIcon /> },
];

export default function AdminDashboard() {
  return (
    <Box>
      <Typography variant="h5" sx={{ fontWeight: 700, mb: 3 }}>Admin Overview</Typography>
      <Grid container spacing={3}>
        {stats.map((s) => (
          <Grid item xs={12} sm={6} md={3} key={s.label}>
            <Card variant="outlined" sx={{ borderRadius: 3 }}>
              <CardContent sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Avatar sx={{ bgcolor: 'secondary.main' }}>{s.icon}</Avatar>
                <Box>
                  <Typography variant="h5" sx={{ fontWeight: 700 }}>{s.value}</Typography>
                  <Typography variant="body2" color="text.secondary">{s.label}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
