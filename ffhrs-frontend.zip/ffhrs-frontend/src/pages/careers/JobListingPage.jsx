import { useMemo, useState } from 'react';
import {
  Container,
  Grid,
  TextField,
  InputAdornment,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  Typography,
  Box,
  Chip,
  Stack,
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import JobCard from '../../components/common/JobCard';
import SectionHeading from '../../components/common/SectionHeading';
import { sampleJobs } from '../../data/sampleJobs';

// NOTE: filtering/search runs client-side over sample data for now.
// Swap this for `useQuery(['jobs', filters], () => axiosClient.get('/jobs', { params: filters }))`
// once the backend Job Search API (with pagination) is available.
export default function JobListingPage() {
  const [search, setSearch] = useState('');
  const [department, setDepartment] = useState('All');
  const [employmentType, setEmploymentType] = useState('All');

  const departments = useMemo(
    () => ['All', ...new Set(sampleJobs.map((j) => j.department))],
    []
  );
  const employmentTypes = useMemo(
    () => ['All', ...new Set(sampleJobs.map((j) => j.employmentType))],
    []
  );

  const filtered = sampleJobs.filter((job) => {
    const matchesSearch =
      job.title.toLowerCase().includes(search.toLowerCase()) ||
      job.skills.some((s) => s.toLowerCase().includes(search.toLowerCase()));
    const matchesDept = department === 'All' || job.department === department;
    const matchesType = employmentType === 'All' || job.employmentType === employmentType;
    return matchesSearch && matchesDept && matchesType;
  });

  return (
    <Container maxWidth="lg" sx={{ py: { xs: 6, md: 10 } }}>
      <SectionHeading eyebrow="Career Portal" title="Find your next opportunity" align="left" />

      <Grid container spacing={2} sx={{ mb: 4 }}>
        <Grid item xs={12} md={6}>
          <TextField
            fullWidth
            placeholder="Search by title or skill (e.g. React, HR Consulting)"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon /></InputAdornment> }}
          />
        </Grid>
        <Grid item xs={6} md={3}>
          <FormControl fullWidth>
            <InputLabel>Department</InputLabel>
            <Select value={department} label="Department" onChange={(e) => setDepartment(e.target.value)}>
              {departments.map((d) => <MenuItem key={d} value={d}>{d}</MenuItem>)}
            </Select>
          </FormControl>
        </Grid>
        <Grid item xs={6} md={3}>
          <FormControl fullWidth>
            <InputLabel>Employment Type</InputLabel>
            <Select value={employmentType} label="Employment Type" onChange={(e) => setEmploymentType(e.target.value)}>
              {employmentTypes.map((t) => <MenuItem key={t} value={t}>{t}</MenuItem>)}
            </Select>
          </FormControl>
        </Grid>
      </Grid>

      <Stack direction="row" spacing={1} sx={{ mb: 3 }}>
        <Chip label={`${filtered.length} jobs found`} color="secondary" variant="outlined" />
      </Stack>

      {filtered.length === 0 ? (
        <Box sx={{ textAlign: 'center', py: 8 }}>
          <Typography color="text.secondary">No jobs match your filters. Try adjusting your search.</Typography>
        </Box>
      ) : (
        <Grid container spacing={3}>
          {filtered.map((job) => (
            <Grid item xs={12} md={6} key={job.id}>
              <JobCard job={job} />
            </Grid>
          ))}
        </Grid>
      )}
    </Container>
  );
}
